# PC BOOST PRO
Versão inicial funcional para Windows.

## Gerar o EXE
1. Instale Python 3.11+ no Windows.
2. Coloque `main.py` e `build_windows.bat` na mesma pasta.
3. Execute `build_windows.bat`.
4. O executável aparecerá em `dist\\PCBoostPro.exe`.

## Recursos
- Dashboard de CPU, RAM, disco e Windows.
- Análise básica.
- Limpeza de temporários com confirmação.
- Lista de processos.
- Acesso às configurações de inicialização.
- Tentativa de ponto de restauração.
- Ferramentas nativas do Windows.
- Informações do PC.

A versão evita alterações agressivas e não encerra processos automaticamente.
