import os, platform, shutil, tempfile, subprocess
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
try:
    import psutil
except ImportError:
    psutil = None

APP = "PC BOOST PRO"

def gb(v): return f"{v/(1024**3):.1f} GB"
def cmd(c):
    try:
        p=subprocess.run(c, shell=True, capture_output=True, text=True, timeout=45)
        return p.returncode, (p.stdout or p.stderr).strip()
    except Exception as e: return -1, str(e)

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP); self.geometry("1180x720"); self.minsize(980,600); self.configure(bg="#0b1020")
        self.style(); self.ui(); self.show_dashboard(); self.after(1500,self.refresh)

    def style(self):
        s=ttk.Style(self)
        try:s.theme_use("clam")
        except:pass
        s.configure("TFrame",background="#0b1020"); s.configure("Card.TFrame",background="#121a2d")
        s.configure("TLabel",background="#0b1020",foreground="#eaf2ff",font=("Segoe UI",10))
        s.configure("Title.TLabel",background="#0b1020",foreground="#fff",font=("Segoe UI Semibold",22))
        s.configure("Sub.TLabel",background="#0b1020",foreground="#8fa4c6",font=("Segoe UI",10))
        s.configure("CardTitle.TLabel",background="#121a2d",foreground="#8fa4c6",font=("Segoe UI Semibold",10))
        s.configure("CardValue.TLabel",background="#121a2d",foreground="#fff",font=("Segoe UI Semibold",18))
        s.configure("Accent.TButton",font=("Segoe UI Semibold",11),padding=10)
        s.configure("Treeview",background="#121a2d",fieldbackground="#121a2d",foreground="#eaf2ff",rowheight=28)
        s.configure("Treeview.Heading",background="#1b2740",foreground="#fff")

    def ui(self):
        top=ttk.Frame(self); top.pack(fill="x",padx=26,pady=(22,10))
        ttk.Label(top,text=APP,style="Title.TLabel").pack(side="left")
        ttk.Label(top,text="  Performance • Segurança • Otimização",style="Sub.TLabel").pack(side="left",pady=(8,0))
        body=ttk.Frame(self); body.pack(fill="both",expand=True,padx=26,pady=10)
        side=ttk.Frame(body); side.pack(side="left",fill="y",padx=(0,18))
        self.content=ttk.Frame(body); self.content.pack(side="left",fill="both",expand=True)
        for n,f in [("Dashboard",self.show_dashboard),("Otimização",self.show_opt),("Limpeza",self.show_clean),
                    ("Processos",self.show_processes),("Inicialização",self.show_startup),("Informações",self.show_info)]:
            ttk.Button(side,text=n,command=f,width=20).pack(fill="x",pady=4)
        ttk.Separator(side,orient="horizontal").pack(fill="x",pady=14)
        ttk.Button(side,text="ANALISAR PC",style="Accent.TButton",command=self.scan).pack(fill="x",pady=4)
        ttk.Button(side,text="Sair",command=self.destroy).pack(fill="x",pady=4)

    def clear(self):
        for w in self.content.winfo_children(): w.destroy()

    def card(self,p,t,v,c):
        f=ttk.Frame(p,style="Card.TFrame",padding=18); f.grid(row=0,column=c,sticky="nsew",padx=5)
        ttk.Label(f,text=t.upper(),style="CardTitle.TLabel").pack(anchor="w")
        l=ttk.Label(f,text=v,style="CardValue.TLabel"); l.pack(anchor="w",pady=(8,0)); return l

    def show_dashboard(self):
        self.clear(); ttk.Label(self.content,text="Visão geral",style="Title.TLabel").pack(anchor="w",pady=(0,15))
        g=ttk.Frame(self.content); g.pack(fill="x")
        for i in range(4):g.columnconfigure(i,weight=1)
        self.cpu=self.card(g,"CPU","--",0); self.ram=self.card(g,"RAM","--",1)
        self.disk=self.card(g,"Disco","--",2); self.win=self.card(g,"Windows","--",3)
        box=ttk.Frame(self.content,style="Card.TFrame",padding=22); box.pack(fill="both",expand=True,pady=16)
        ttk.Label(box,text="Status do computador",style="CardTitle.TLabel").pack(anchor="w")
        self.health=ttk.Label(box,text="Aguardando análise...",background="#121a2d",foreground="#fff",font=("Segoe UI Semibold",26))
        self.health.pack(anchor="w",pady=(12,4))
        self.details=ttk.Label(box,text="",background="#121a2d",foreground="#9fb1cf",font=("Segoe UI",11),justify="left")
        self.details.pack(anchor="w",pady=8)
        ttk.Button(box,text="🚀 OTIMIZAÇÃO INTELIGENTE",style="Accent.TButton",command=self.scan).pack(anchor="w",pady=14)

    def refresh(self):
        if psutil:
            try:
                c=psutil.cpu_percent(); m=psutil.virtual_memory(); d=psutil.disk_usage(os.path.abspath(os.sep))
                if hasattr(self,"cpu"): self.cpu.config(text=f"{c:.0f}%")
                if hasattr(self,"ram"): self.ram.config(text=f"{m.percent:.0f}% • {gb(m.used)} / {gb(m.total)}")
                if hasattr(self,"disk"): self.disk.config(text=f"{d.percent:.0f}% • {gb(d.free)} livres")
                if hasattr(self,"win"): self.win.config(text=f"{platform.system()} {platform.release()}")
                if hasattr(self,"details"): self.details.config(text=f"Processadores: {psutil.cpu_count(logical=True)} lógicos\nArquitetura: {platform.machine()}\nHost: {platform.node()}")
            except: pass
        self.after(1500,self.refresh)

    def scan(self):
        if not psutil:return messagebox.showerror(APP,"Instale psutil para monitorar o PC.")
        c=psutil.cpu_percent(interval=.4); m=psutil.virtual_memory().percent; d=psutil.disk_usage(os.path.abspath(os.sep)).percent
        a=[]
        if c>=85:a.append("CPU com uso elevado agora")
        if m>=85:a.append("RAM com uso elevado")
        if d>=90:a.append("Pouco espaço livre no disco")
        self.health.config(text=f"{len(a)} ponto(s) de atenção" if a else "PC em condição normal")
        self.details.config(text="\n".join("• "+x for x in a) if a else "• Nenhum alerta básico de uso foi detectado.\n• Isso não substitui diagnóstico técnico completo.")
        messagebox.showinfo(APP,"Análise concluída.\n\n"+("\n".join(a) if a else "Nenhum alerta básico encontrado."))

    def show_opt(self):
        self.clear(); ttk.Label(self.content,text="Otimização segura",style="Title.TLabel").pack(anchor="w")
        b=ttk.Frame(self.content,style="Card.TFrame",padding=22); b.pack(fill="x",pady=18)
        ttk.Label(b,text="Ações disponíveis",style="CardTitle.TLabel").pack(anchor="w")
        for t,f in [("Limpar arquivos temporários",self.clean_temp),("Abrir Apps de Inicialização",self.open_startup),
                    ("Criar ponto de restauração",self.restore_point),("Abrir Windows Update",lambda:cmd("start ms-settings:windowsupdate"))]:
            ttk.Button(b,text=t,command=f).pack(fill="x",pady=6)
        ttk.Label(b,text="Ações pedem confirmação e evitam tweaks agressivos.",style="Sub.TLabel").pack(anchor="w",pady=(14,0))

    def temp_size(self):
        total=0
        try:
            for x in Path(tempfile.gettempdir()).rglob("*"):
                if x.is_file():
                    try:total+=x.stat().st_size
                    except:pass
        except:pass
        return total

    def show_clean(self):
        self.clear(); ttk.Label(self.content,text="Limpeza",style="Title.TLabel").pack(anchor="w")
        b=ttk.Frame(self.content,style="Card.TFrame",padding=22); b.pack(fill="x",pady=18)
        ttk.Label(b,text=f"Temporários detectados: {gb(self.temp_size())}",style="CardValue.TLabel").pack(anchor="w")
        ttk.Label(b,text="Somente a pasta temporária do usuário será considerada.",style="Sub.TLabel").pack(anchor="w",pady=8)
        ttk.Button(b,text="Limpar arquivos temporários",command=self.clean_temp).pack(anchor="w",pady=12)

    def clean_temp(self):
        if not messagebox.askyesno(APP,"Excluir arquivos temporários do usuário?\nArquivos em uso serão ignorados."):return
        total=0
        for x in list(Path(tempfile.gettempdir()).iterdir()):
            try:
                if x.is_file() or x.is_symlink():total+=x.stat().st_size;x.unlink(missing_ok=True)
                elif x.is_dir():shutil.rmtree(x,ignore_errors=True)
            except:pass
        messagebox.showinfo(APP,f"Limpeza concluída.\nEspaço removido: {gb(total)}")

    def show_processes(self):
        self.clear(); ttk.Label(self.content,text="Processos",style="Title.TLabel").pack(anchor="w",pady=(0,10))
        fr=ttk.Frame(self.content,style="Card.TFrame",padding=10); fr.pack(fill="both",expand=True)
        tr=ttk.Treeview(fr,columns=("pid","name","ram"),show="headings")
        for c,t,w in [("pid","PID",80),("name","Processo",420),("ram","RAM",140)]:
            tr.heading(c,text=t);tr.column(c,width=w)
        tr.pack(fill="both",expand=True)
        if psutil:
            rows=[]
            for p in psutil.process_iter(["pid","name","memory_info"]):
                try:rows.append((p.info["pid"],p.info["name"] or "",p.memory_info().rss))
                except:pass
            for pid,n,r in sorted(rows,key=lambda z:z[2],reverse=True)[:150]:tr.insert("","end",values=(pid,n,gb(r)))
        ttk.Button(self.content,text="Atualizar",command=self.show_processes).pack(anchor="w",pady=8)

    def show_startup(self):
        self.clear(); ttk.Label(self.content,text="Inicialização",style="Title.TLabel").pack(anchor="w")
        b=ttk.Frame(self.content,style="Card.TFrame",padding=22);b.pack(fill="both",expand=True,pady=15)
        ttk.Label(b,text="Inicialização do Windows",style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(b,text="Use as ferramentas nativas do Windows para revisar e alterar itens com segurança.",style="Sub.TLabel").pack(anchor="w",pady=10)
        ttk.Button(b,text="Abrir Gerenciador de Tarefas",command=lambda:cmd("taskmgr.exe")).pack(anchor="w",pady=6)
        ttk.Button(b,text="Abrir Apps de Inicialização",command=self.open_startup).pack(anchor="w",pady=6)

    def open_startup(self):cmd("start ms-settings:startupapps")

    def restore_point(self):
        if not messagebox.askyesno(APP,"Tentar criar um ponto de restauração do Windows?"):return
        c=r'''powershell -NoProfile -ExecutionPolicy Bypass -Command "Checkpoint-Computer -Description 'PC BOOST PRO - Antes da otimizacao' -RestorePointType 'MODIFY_SETTINGS'"'''
        code,out=cmd(c)
        messagebox.showinfo(APP,"Solicitação enviada ao Windows." if code==0 else "Não foi possível criar o ponto automaticamente.\n\n"+out)

    def show_info(self):
        self.clear();ttk.Label(self.content,text="Informações do PC",style="Title.TLabel").pack(anchor="w")
        b=ttk.Frame(self.content,style="Card.TFrame",padding=22);b.pack(fill="both",expand=True,pady=15)
        vals=[("Sistema",platform.platform()),("Arquitetura",platform.machine()),("CPU",platform.processor() or "Não informado"),
              ("Núcleos",str(psutil.cpu_count(logical=False)) if psutil else "—"),("Threads",str(psutil.cpu_count(logical=True)) if psutil else "—")]
        for k,v in vals:ttk.Label(b,text=f"{k}: {v}",background="#121a2d",foreground="#dce8ff",font=("Segoe UI",11)).pack(anchor="w",pady=6)

if __name__=="__main__":App().mainloop()
