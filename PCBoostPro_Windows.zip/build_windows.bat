@echo off
setlocal
title PC BOOST PRO - BUILD
py -3 -m pip install --upgrade pip
py -3 -m pip install psutil pyinstaller
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name PCBoostPro main.py
echo.
echo EXE GERADO: dist\PCBoostPro.exe
pause
